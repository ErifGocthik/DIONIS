<div class="admin-default-index">
    <h1 class="dionis py-2">ADMIN-<strong class="georgia">Панель</strong></h1>
    <a href="<?php echo \yii\helpers\Url::toRoute(['events/index'])?>" class="btn btn-event georgia admin-btn">События</a>
    <a href="<?php echo \yii\helpers\Url::toRoute(['user/index'])?>" class="btn btn-event georgia admin-btn">Пользователи</a>
</div>
